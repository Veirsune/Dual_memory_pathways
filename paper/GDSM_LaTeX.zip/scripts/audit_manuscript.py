"""Check manuscript quantities against copied results; never train or alter models."""
import csv,json,re,hashlib,statistics,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[1]
checks=[]
def check(name,ok,details=None):
 checks.append({'check':name,'passed':bool(ok),'details':details});assert ok,(name,details)
def csvread(name):return list(csv.DictReader((R/'evidence'/name).open()))
# Source files must match archived hashes.
for row in json.loads((R/'evidence/source-manifest.json').read_text()):
 check('source checksum: '+row['file'],hashlib.sha256((R/row['file']).read_bytes()).hexdigest()==row['sha256'])
# Reconstruct the archived SHD controls behind the component comparisons.
a=csvread('shd-supervision.csv')
expected={
(10,'task_only'):[85.62,2.06,31.38,3.19,41.64,9.83,73.28,2.51],
(10,'zero_rule'):[86.31,1.11,58.42,4.47,46.29,8.23,72.97,1.60],
(10,'joint_supervised'):[86.10,1.85,60.38,4.03,53.47,4.17,69.05,1.82],
(30,'task_only'):[87.38,.98,29.52,6.19,56.96,12.77,75.89,1.27],
(30,'zero_rule'):[87.99,.87,67.82,5.48,60.16,8.76,75.63,1.59],
(30,'joint_supervised'):[87.99,.19,66.84,7.17,60.81,13.50,73.29,.27]}
for (d,mode),want in expected.items():
 rs=[r for r in a if r['split']=='official_test' and int(r['d'])==d and r['mode']==mode];got=[]
 for metric in ['clean','silence','noise','switch']:
  v=[float(r[metric])*100 for r in rs];got.extend([round(statistics.mean(v),2),round(statistics.stdev(v),2)])
 check(f'SHD supervision d{d} {mode}',got==want,{'actual':got,'expected':want})
b=csvread('shd-capacity.csv')
for d,drive,aux,ret in [(10,'scalar',48.19,40.15),(10,'wide_scalar',56.67,47.46),(10,'vector',68.24,51.88),(30,'scalar',68.82,52.65),(30,'wide_scalar',69.57,59.76),(30,'vector',81.05,66.70)]:
 rs={r['condition']:r for r in b if r['key']==f'robust-{drive}_protected-d{d}-s501'}
 actual=[round(float(rs['clean']['aux_endpoint_accuracy_single'])*100,2),round(statistics.mean(float(rs[k]['accuracy_retained'])*100 for k in ['pair-silence-L80','pair-poisson-L80']),2)]
 check(f'SHD capacity d{d} {drive}',actual==[aux,ret],actual)
# All headline quantities derive from raw csv accuracy (not copied rounded text).
claims=json.loads((R/'evidence/generated-claims.json').read_text())
def value(task,family,L,kind):
 c=[v for v in claims if v['task']==task and v['family']==family and v['phase']=='mixed' and v['metric']=='last20' and v['L']==L and v['kind']==kind and not v['middle']]
 assert len(c)==1
 return round(c[0]['mean'],2)
for t,f,L,k,want in [('SSC','commit',120,'poisson',52.79),('SSC','dmp',120,'poisson',3.91),('DVS Gesture','commit',80,'silence',70.83),('DVS Gesture','dmp',80,'silence',19.70),('S-MNIST','commit',160,'silence',78.68),('S-MNIST','dmp',160,'silence',8.69)]:
 check('gap endpoints '+str((t,f,L,k)),value(t,f,L,k)==want)
# Float schedule arithmetic and exact-integer scope.
replay=json.loads((R/'evidence/hardware-replay.json').read_text())
check('native replay archived outcome',replay['passed'] and replay['steps']==944 and replay['checked_values']==117056 and replay['cycles']==185528 and not replay['full_classifier'])
check('real trace cached cycles',188800-818*4==185528)
check('real trace cycle saving',round((188800-185528)/188800*100,2)==1.73)
check('gate coordinate count',944*40==37760)
check('scalar-DMP cycles',[(1+d+32) for d in (10,30)]==[43,63])
check('dense Commit cycles',[(4*d+32+64) for d in (10,30)]==[136,216])
check('closed Commit cycles',[(4*d+32+32) for d in (10,30)]==[104,184])
# Compare the plotted full-network MAC estimates with the archived operation counts.
ops={(v['family'],v['condition']):v for v in csvread('hardware-operations.csv')}
full=json.loads((R/'evidence/full-network-mac-claims.json').read_text())
for v in full:
 d=ops['dmp',v['condition']];c=ops['commit',v['condition']]
 check('network MAC scope '+v['condition'],abs(v['dmp_macs']-float(d['whole_mapped_mac']))<1e-6 and abs(v['commit_cached_macs']-float(c['whole_mapped_mac']))<1e-6)
 check('dense versus cached '+v['condition'],abs(v['commit_dense_macs']-v['commit_cached_macs']-float(c['stable_read_mac_saved']))<1e-6)
check('clean whole-network overhead',round(full[0]['cached_overhead_percent'],2)==6.30)
check('tail whole-network overhead',round(full[1]['cached_overhead_percent'],2)==6.70)
check('tail cache saving',round(full[1]['cache_saving_percent'],3)==1.183)
text=(R/'main.tex').read_text();log=(R/'GDSM_Paper.log').read_text()
check('no unfinished manuscript markers',not re.search(r'\b(TODO|FIXME|TBD|INSERT HERE)\b',text))
check('no unresolved citations or references','undefined' not in log.lower())
check('no overflowing boxes','Overfull' not in log)
check('no LaTeX errors','! LaTeX Error' not in log)
info=subprocess.check_output(['pdfinfo',str(R/'GDSM_Paper.pdf')],text=True)
pages=int(re.search(r'Pages:\s+(\d+)',info).group(1))
extracted=subprocess.check_output(['pdftotext',str(R/'GDSM_Paper.pdf'),'-'],text=True)
check('complete PDF',pages>0 and all(v in ' '.join(extracted.split()) for v in ['813','117,056','Energy on silicon remains to be measured.']),{'pages':pages})
zh_text=(R/'main_zh.tex').read_text()
headings={
    'English': (text, ['Introduction','Gated dual-state memory','Experimental design','Results','Implementation cost and hardware verification','Discussion and conclusion'], r'\bibliography{references}'),
    'Chinese': (zh_text, ['引言','门控双状态记忆','实验设计','实验结果','实现开销与硬件验证','讨论与结论'], r'\input{main.bbl}'),
}
figures=['architecture','retention','training','speech','paired','hardware']
equations=['dmp','candidate','stable','read','gate','loss']
for language,(document,section_titles,bibliography) in headings.items():
    sections=re.split(r'(?m)^\\section\{([^}\n]+)\}',document)
    check(language+' main section order',sections[1::2]==section_titles)
    check(language+' manuscript ends with references',document.split(bibliography)[-1].strip()==r'\end{document}' and r'\appendix' not in document)
    check(language+' numbered equations in method order',re.findall(r'\\label\{eq:([^}]+)\}',sections[4])==equations and document.count(r'\begin{equation}')==len(equations))
    check(language+' figure order',re.findall(r'\\label\{fig:([^}]+)\}',document)==figures)
    check(language+' table order',re.findall(r'\\label\{tab:([^}]+)\}',document)==['protocol','retention','capacity','recognition'])
check('original DMP notation preserved',all(v in text for v in [r's^{l-1}[k]',r'u^l[k]',r'x^l[k]',r'm^l[k]',r'W_x',r'f_x(',r'\bar B',r'I_m^l[k]']) and not any(v in text for v in [r'u_t',r'h_t',r'W_u',r'W_h',r'\relu(',r'\bar b']))
check('raw-input closure rule',r'\ind[\|s^0[k]\|_1>0]' in text)
check('headline quantities typeset',all(v in text and v in zh_text for v in ['72.34','75.29','23.17','32.83','28.84','17.73','15.33','813','489','52.79','3.91','78.68','8.69','117,056','6.30']))
check('plot uses matching notation',all(v in (R/'scripts/draw_architecture.py').read_text() for v in ['$s[k]$',r'$W_f$',r'$\bar B\odot \mathbf{x}[k]$',r'$p[k-1]$',r'$W_m$']))
# Learning curves must reproduce archived validation histories, not training/test scores.
from draw_training_curves import training_points
curve_points=training_points(R)
check('training histories and evaluation schedules',len(curve_points)==96)
curve_csv=csvread('training-curve-points.csv')
check('plotted training aggregates match histories',len(curve_csv)==len(curve_points) and all(all(row[k]==str(point[k]) for k in ['task','family','stage','epoch','seeds']) and all(abs(float(row[k])-point[k])<1e-12 for k in ['mean','sd']) for row,point in zip(curve_csv,curve_points)))
# Check every noise position against the paired utterance-level predictions.
import numpy as np
folder=R/'evidence/ssc-position'
rows=list(csv.DictReader((folder/'accuracy.csv').open()))
families={'FSNN':'fsnn','DMP':'dmp','GDSM':'commit'}
with np.load(folder/'predictions.npz') as preds:
 labels=preds['labels']
 check('SSC timing design',len(labels)==20382 and len(rows)==18 and
       {(r['model'],r['overlap_frames']) for r in rows}==
       {(m,k) for m in families for k in ['clean','0','20','40','60','80']})
 for row in rows:
  key=families[row['model']]+'_'+row['overlap_frames']
  hits=int((preds[key]==labels).sum())
  check('SSC timing '+key,int(row['correct'])==hits and int(row['n'])==len(labels)
        and abs(float(row['accuracy_pct'])-100*hits/len(labels))<1e-6)
# Whole-word classification under continuous additive noise.
speech=R/'evidence/ssc-speech'
rates=json.loads((speech/'protocol.json').read_text())['poisson_rates']
records=list(csv.DictReader((speech/'accuracy.csv').open()))
check('SSC speech conditions',len(records)==12 and {(r['model'],float(r['poisson_rate'])) for r in records}=={(m,r) for m in families for r in rates})
with np.load(speech/'predictions.npz') as preds, np.load(folder/'predictions.npz') as archived:
 labels=preds['labels']
 check('same SSC test order',np.array_equal(labels,archived['labels']) and len(labels)==20382)
 for r in records:
  key=families[r['model']]+'_'+str(rates.index(float(r['poisson_rate'])))
  hits=int(np.count_nonzero(preds[key]==labels))
  check('SSC whole-word '+key,int(r['correct'])==hits and int(r['n'])==len(labels) and abs(float(r['accuracy_pct'])-100*hits/len(labels))<1e-6)
paired=csvread('paired-effects.csv')
for task in ('shd-matched','gesture','ssc-repair'):
 rows=[r for r in paired if r['dataset']==task and r['comparison']=='DMP / GDSM']
 check('paired official cohort '+task,len(rows)==5)
 for row in rows:
  net=int(row['only_b_shared'])-int(row['only_a_shared'])
  check('paired changed predictions '+task+' '+row['condition'],net==int(row['b_correct_shared'])-int(row['a_correct_shared']) and abs(float(row['shared_delta_pp'])-100*net/int(row['n_both_clean']))<1e-8)
# Recompute the numbers behind the five-row ordinary recognition table.
recognition = {}
for dataset, label in [('shd-matched', 'SHD'), ('ssc-repair', 'SSC'), ('gesture', 'DVS Gesture')]:
    [row] = [r for r in paired if r['dataset']==dataset and r['comparison']=='DMP / GDSM' and r['condition']=='clean']
    recognition[label] = (int(row['n']), float(row['acc_a']), float(row['acc_b']))
image_rows = csvread('mnist.csv')
for task, label in [('smnist','S-MNIST'), ('psmnist','PS-MNIST')]:
    scores = []
    for family in ('dmp', 'commit'):
        rows = [r for r in image_rows if r['task']==task and r['family']==family
                and r['phase']=='mixed' and r['metric']=='mean' and r['name']=='clean']
        assert sorted(int(r['seed']) for r in rows)==[42,43,44]
        assert all(int(r['n'])==10000 for r in rows)
        scores.append(statistics.mean(100*float(r['accuracy']) for r in rows))
    recognition[label] = (10000, *scores)
for task, (n, dmp, gdsm) in recognition.items():
    delta = gdsm - dmp
    signed = f'{delta:+.2f}' if delta else '0.00'
    table_row = f'{task} & {n:,} & {dmp:.2f} & {gdsm:.2f} & ${signed}$'
    check('ordinary recognition table '+task, all(table_row in doc for doc in (text, zh_text)))

# Four predictions per word verify the effect of keeping the prefix state.
midpoint = json.loads((R/'evidence/ssc-midpoint.json').read_text())
with np.load(R/'evidence/ssc-midpoint.npz') as data:
    labels = data['labels']
    check('midpoint test cohort', len(labels)==midpoint['n']==20382 and len(np.unique(data['speakers']))==midpoint['speakers']==498)
    for cond in ('clean','noise'):
        keep = data[cond+'_keep'] == labels
        reset = data[cond+'_reset'] == labels
        net = int(keep.sum()) - int(reset.sum())
        result = midpoint[cond]
        check('midpoint correct counts '+cond, (int(keep.sum()), int(reset.sum()), int((keep & ~reset).sum()), int((reset & ~keep).sum())) ==
              (result['keep_correct'], result['reset_correct'], result['keep_only'], result['reset_only']))
        values = [f'{100*keep.mean():.2f}', f'{100*reset.mean():.2f}', str(net)]
        check('midpoint values in both languages '+cond, all(v in doc for v in values for doc in (text, zh_text)))
[stable] = [r for r in paired if r['dataset']=='ssc-repair' and r['comparison']=='GDSM stable read off / full' and r['condition']=='clean']
check('stable readout dependence', all(f"{float(stable[k]):.2f}" in doc for doc in (text,zh_text) for k in ('acc_a','acc_b')))
report={'status':'passed','checks':checks,'pages':pages,'new_training_runs':0,'note':'Numerical/source and compilation audit; figure pages are also visually inspected. Scientific interpretation is described in the manuscript.'}
(R/'evidence/manuscript-audit.json').write_text(json.dumps(report,indent=2))
print(f'Passed {len(checks)} checks; {pages} PDF pages; verified frozen evaluations.')
